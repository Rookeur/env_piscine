#ifndef MY_HEADER_H
#define MY_HEADER_H

int my_fibo();


#endif
