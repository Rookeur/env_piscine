#!/bin/sh

TIME=1

[ "$#" -ne 0 ] && [ "$1" -gt 0 ] && TIME="$1"
watch -c -n "$TIME" 'make; ./unit_test.out'
