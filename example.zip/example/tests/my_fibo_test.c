#include <criterion/criterion.h>
#include <criterion/redirect.h>
#include <signal.h>
#include "my_header.h"
#include <stdio.h>

void redirect_all_stdout(void)
{
        cr_redirect_stdout();
        cr_redirect_stderr();
}

Test(fibo, is_declared)
{
        my_fibo(0);
}

Test(fibo, fibo_0_return_0)
{
        cr_assert_eq(0, my_fibo(0));
}

Test(fibo, fibo_1_return_1)
{
        cr_assert_eq(1, my_fibo(1));
}

Test(fibo, fibo_2_return_1)
{
        cr_assert_eq(1, my_fibo(2));
}

Test(fibo, fibo_3_return_2)
{
        cr_assert_eq(2, my_fibo(3));
}

Test(fibo, fibo_4_return_3)
{
        cr_assert_eq(3, my_fibo(4));
}

Test(fibo, fibo_5_return_5)
{
        cr_assert_eq(5, my_fibo(5));
}

Test(fibo, fibo_6_return_8)
{
        cr_assert_eq(8, my_fibo(6));
}

Test(fibo, fibo_7_return_13)
{
        cr_assert_eq(13, my_fibo(7));
}

Test(fibo, fibo_8_return_21)
{
        cr_assert_eq(21, my_fibo(8));
}

Test(fibo, fibo_16_return_987)
{
        cr_assert_eq(987, my_fibo(16));
}

Test(fibo, fibo_negative_signal_sigint, .exit_code = 1, .disabled = 1)
{
        my_fibo(-1);
}

Test(fibo, fibo_negative_stderr_message, .init = redirect_all_stdout)
{
    my_fibo(-2);
    cr_assert_stderr_eq_str("FAIL", "NOT THE RIGHT OUTPUT");
}
