#include <signal.h>
#include <stdlib.h>
#include <stdio.h>

int my_fibo(int n)
{
    if (n < 0)
    {
        fprintf(stderr, "FAIL");
        return 0;
    }
    else if (n < 2)
        return n;
    else
        return my_fibo(n-1) + my_fibo(n-2);
}
